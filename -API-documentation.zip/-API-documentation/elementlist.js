
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","load()"],["f","loadPath()"],["c","Quaver\\Core\\Bootstrap"],["c","Quaver\\Core\\Config"],["c","Quaver\\Core\\Controller"],["c","Quaver\\Core\\DB"],["c","Quaver\\Core\\Exception"],["c","Quaver\\Core\\Helper"],["c","Quaver\\Core\\Lang"],["c","Quaver\\Core\\LangStrings"],["c","Quaver\\Core\\Log"],["c","Quaver\\Core\\Model"],["c","Quaver\\Core\\Resources"],["c","Quaver\\Core\\Router"]];
